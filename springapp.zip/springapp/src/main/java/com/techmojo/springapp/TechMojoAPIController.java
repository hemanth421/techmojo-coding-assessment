package com.techmojo.springapp;

import java.util.Timer;
import java.util.TimerTask;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.techmojo.dto.SampleInputDto;
import com.techmojo.interfaces.ITechMojoAPI;
import com.techmojo.util.TenantUtil;


@RestController
public class TechMojoAPIController {
	
	private ITechMojoAPI techMojoApiImpl;

	public void setTechMojoApiImpl(ITechMojoAPI techMojoApiImpl) {
		this.techMojoApiImpl = techMojoApiImpl;
	}

	@RequestMapping(value="/mojoapi", method = RequestMethod.GET)
	public String myApi(@RequestBody SampleInputDto sampleInputDto) {
		boolean limitExceeded = TenantUtil.isLimitedExceeded(sampleInputDto.getTenantId());
		if(limitExceeded) {
			techMojoApiImpl.addToQueue(sampleInputDto);
			return "limit-exceeded";
		}else {
			return "response-view";
		}
	}
}
