package com.techmojo.springapp;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Queue;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.techmojo.dto.SampleInputDto;
import com.techmojo.util.TenantUtil;

public class LoadOnStartUp implements InitializingBean{

	public void afterPropertiesSet() throws Exception {
		TimerTask task = new TimerTask() {
	        public void run() {
	            TenantUtil.refreshTokens();
	            Queue<SampleInputDto> queue = TenantUtil.getTenantQueue();
	            if(queue != null) {
		            ClassPathXmlApplicationContext ctxt = new ClassPathXmlApplicationContext("application-context.xml");
		            TechMojoAPIController techMojoAPIController = (TechMojoAPIController) ctxt.getBean("techMojoAPIController");
		            while(!queue.isEmpty()) {
		            	SampleInputDto sampleInputDto = queue.poll();
		            	techMojoAPIController.myApi(sampleInputDto);
		            }
	            }
	        }
	    };
	    Timer timer = new Timer("apiTimer");
	    
	    long delay = 60000L; //1minute
	    timer.schedule(task, delay);
	}

}
