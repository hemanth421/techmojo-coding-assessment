package com.techmojo.springapp;

import org.springframework.stereotype.Service;

import com.techmojo.dto.SampleInputDto;
import com.techmojo.interfaces.ITechMojoAPI;
import com.techmojo.util.TenantUtil;

@Service
public class TechMojoApiImpl implements ITechMojoAPI{

	public void addToQueue(SampleInputDto sampleInputDto) {
		TenantUtil.addToQueue(sampleInputDto);
	}
	
}
