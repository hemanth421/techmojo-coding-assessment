package com.techmojo.util;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

import com.techmojo.dto.SampleInputDto;

public class TenantUtil {
	
	private static Map<String, Integer> tenantLimitMap;
	private static Queue<SampleInputDto> tenantQueue;
	
	public Map<String, Integer> getTenantLimitMap(){
		return tenantLimitMap;
	}
	
	public static Queue<SampleInputDto> getTenantQueue() {
		return tenantQueue;
	}

	public static void refreshTokens(){
		tenantLimitMap = new ConcurrentHashMap<String, Integer>();
		//map has third party company name and its respective max no.of calls that can be for a minute 
		tenantLimitMap.put("TCS",20);
		tenantLimitMap.put("Infosys",15);
		tenantLimitMap.put("Google",10);
	}
	
	public static boolean isLimitedExceeded(String tenantId) {
		if(tenantLimitMap.get(tenantId)>0) {
			tenantLimitMap.put(tenantId, tenantLimitMap.get(tenantId)-1);
			return false;
		}else {
			return true;
		}
	}
	
	public static void addToQueue(SampleInputDto sampleInputDto) {
		if(tenantQueue == null) {
			tenantQueue = new LinkedList<SampleInputDto>();
		}
		tenantQueue.add(sampleInputDto);
	}
}
