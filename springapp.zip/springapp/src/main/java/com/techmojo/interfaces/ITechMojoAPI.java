package com.techmojo.interfaces;

import com.techmojo.dto.SampleInputDto;

public interface ITechMojoAPI {
	public void addToQueue(SampleInputDto sampleInputDto);
}
